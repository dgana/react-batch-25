import React, { Component } from 'react'
import { connect } from 'react-redux'
import {
  fetchPeople,
  deletePerson,
  fetchMorePeople
} from '../../actions/starwars'

class People extends Component {
  constructor(props) {
    super(props)
    this.state = {
      page: 1
    }
    this.loadMore = this.loadMore.bind(this)
  }

  componentDidMount() {
    this.props.fetchPeople()
  }

  loadMore() {
    const { fetchMorePeople } = this.props
    this.setState(
      state => ({ page: state.page + 1 }),
      () => fetchMorePeople(this.state.page)
    )
  }

  render() {
    const { loading, people, deletePerson, errorMessage } = this.props

    if (errorMessage) {
      return <p>{errorMessage}</p>
    }
    return (
      <div>
        {loading && <p>Loading...</p>}
        <div className="m-auto w10">
          {people.map(x => (
            <div className="flex justify-between align-center" key={x.id}>
              <p>{x.name}</p>
              <p
                className="pointer w4 h4 white"
                onClick={() => deletePerson(x.id)}
              >
                Delete Person
              </p>
            </div>
          ))}
          <button onClick={this.loadMore}>Load More...</button>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  loading: state.starwars.loading,
  people: state.starwars.people,
  errorMessage: state.starwars.errorMessage
})

const mapDispatchToProps = dispatch => ({
  fetchPeople: () => dispatch(fetchPeople()),
  deletePerson: id => dispatch(deletePerson(id)),
  fetchMorePeople: page => dispatch(fetchMorePeople(page))
})

export default connect(mapStateToProps, mapDispatchToProps)(People)
