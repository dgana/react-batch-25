import React from 'react'

const About = () => {
  return (
    <div className="white">
      <p>This is about page</p>
    </div>
  )
}

export default About
