import { combineReducers } from 'redux'

import starwars from './starwars'

const myApp = combineReducers({
  starwars
})

export default myApp
